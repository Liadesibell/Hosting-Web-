# KökHost

SQLite kullanıcı hesapları, web ve e-posta hosting paketleri, destek talepleri, alan adı sorgulama ve yapay zekâ asistanı içeren hosting satış sitesi ve müşteri paneli.

## Yerel ortamda çalıştırma

Gereksinimler: Node.js 22.5 veya üzeri ve npm. SQLite, Node.js ile birlikte gelir. `data/kokhost.sqlite` dosyası uygulama ilk kez başlatıldığında oluşturulur.

```powershell
npm.cmd install
npm.cmd start
```

Tarayıcıda http://localhost:3000 adresini açın. Windows'ta `start.bat`, eksik bağımlılıkları yükler, sunucuyu başlatır ve terminal penceresini açık tutar.

### Live Server ile kullanma

İsterseniz arayüzü VS Code Live Server üzerinden `http://localhost:5500` adresinde açabilirsiniz. `.vscode/settings.json`, Live Server'ın dosya kökünü `public` klasörü olarak ayarlar; böylece `/panel.html` gibi sayfa adresleri bulunabilir. Bunun için Node.js sunucusunu ayrıca çalışır durumda bırakın; arayüz API isteklerini otomatik olarak `http://localhost:3000` adresine gönderir. Live Server'ın varsayılan `5500` portu desteklenir. Ayarı uygulamak için Live Server'ı yeniden başlatın ve sunucu terminallerini açık bırakın.

## Müşteri paneli sayfaları

Her kanalın ayrı HTML adresi vardır: `panel.html` (Genel Bakış), `packages.html` (Paketler), `domains.html` (Alan Adı), `support.html` (Destek), `payments.html` (Sipariş ve Ödeme), `assistant.html` (yerel hazır yanıtlar), `cart.html` (Sepet), `verify.html` (E-posta doğrulama) ve `admin.html` (Yönetim). Tüm sayfalar ortak menü ve ödeme penceresini `panel-layout.js` dosyasından alır; kanal içeriği ile sayfa geçişleri `panel.js` içindedir. Görsel düzen tek `panel.css` dosyasında tutulur.

Paketler kanalının ilk ekranında müşteri önce Hosting, VDS/VPS, Özel Sunucu, Domain, Kampanyalar veya kendi paketini oluştur kategorilerinden birini seçer. Seçimden sonra yalnız ilgili grubun paketleri tek sayfada listelenir. Web hosting, VDS/VPS ve özel sunucu ailelerinin her birinde 50 seçenek vardır. Özel yapılandırıcıda CPU, RAM, depolama, işletim sistemi, kontrol paneli ve yedekleme seçilebilir; ekranda gösterilen formül tahmini aylık fiyat üretir. Sepet toplamı ödeme öncesinde API tarafından yeniden hesaplanır. Bu örnek fiyatlar sağlayıcı teklifi değildir; gerçek satış öncesinde donanım, lisans ve vergi maliyetlerine göre güncellenmelidir.

## Entegrasyonları yapılandırma

`.env.example` dosyasını `.env` adıyla kopyalayıp servis sağlayıcı bilgilerini ekleyin. `.env` dosyasını asla Git deposuna eklemeyin veya servis sırlarını sohbetlerde paylaşmayın.

- **Müşteri ve yönetici erişimi:** Destek yönetimi ve havale onaylama yetkilerini almak için `ADMIN_EMAIL` değişkeninde belirtilen e-posta adresiyle hesap oluşturun.
- **IBAN ile ödeme:** `COMPANY_IBAN`, `BANK_NAME` ve `BANK_ACCOUNT_NAME` değişkenlerini ayarlayın. Yönetici panelden ödemeyi doğrulayana kadar havale beklemede kalır.
- **Kartla ödeme:** PayTR mağaza numarasını, anahtarını ve tuz değerini; ayrıca herkese açık HTTPS adresini `PUBLIC_URL` olarak yapılandırın. PayTR mağaza panelindeki bildirim adresini `PUBLIC_URL/api/payments/paytr/callback` olarak ayarlayın. Kart ve 3D Secure sayfası PayTR tarafından sunulur; bu uygulama kart numaralarını saklamaz. Geri bildirim adresine internet üzerinden erişilebilmelidir. Güvenilir bir ters proxy kullanıyorsanız PayTR'ye ziyaretçinin gerçek IP adresinin iletilmesi için `TRUST_PROXY` değişkenini Express tarafından belgelenen uygun değerle ayarlayın.
- **Destek e-postası ve ödeme onayı:** SMTP'yi, `MAIL_FROM`, `ADMIN_EMAIL` ve `SUPPORT_EMAIL` değişkenlerini yapılandırın. Gmail'e giden doğrulama bağlantıları için `PUBLIC_URL` herkese açık HTTPS domaini olmalıdır; `localhost` bağlantıları Gmail'de spam'e düşebilir ve başka cihazlardan açılamaz. Gönderen adresi SMTP hesabıyla aynı olmalı veya sağlayıcıda doğrulanmış bir takma ad olmalıdır. Kendi domaininizde SPF, DKIM ve DMARC kayıtlarını e-posta sağlayıcınızın yönergelerine göre doğrulayın; SMTP'nin iletiyi kabul etmesi gelen kutusuna teslim garantisi vermez. IBAN ödeme bildirimi yönetici ve destek adreslerine sipariş, paket ve tutar ayrıntılarıyla gönderilir. E-postayı `ONAYLANDI` yazarak yanıtlamak için destek posta kutusunun IMAP bilgilerini `IMAP_HOST`, `IMAP_USER`, `IMAP_PASS`, isteğe bağlı `IMAP_PORT` (varsayılan `993`), `IMAP_SECURE` (varsayılan `true`), `IMAP_MAILBOX` (varsayılan `INBOX`) ve `IMAP_POLL_INTERVAL_MS` (varsayılan `10000`) değişkenlerine ekleyin. Yanıt göndereni `ADMIN_EMAIL` veya `SUPPORT_EMAIL` olmalıdır. E-posta yanıtı ya da yönetim panelindeki ödeme talebine verilen tam `ONAYLANDI` yanıtı ödemeyi onaylar ve hizmeti müşterinin Hizmetler kanalında açar. IMAP ayarları yapılmazsa onay yönetim panelindeki talep üzerinden verilmelidir.
- **Hesap e-posta doğrulaması:** Yeni hesap, SMTP ile doğrulama e-postası gönderilemezse oluşturulmaz. Kullanıcı, e-postadaki bağlantıyı açıp doğrulama düğmesine bastığında hesap etkinleşir; doğrulanmamış kayıtlar 24 saat sonra temizlenir.
- **E-postanın açılma durumu:** E-posta istemcisi izleme görselini yüklediğinde ileti açılmış olarak işaretlenir. Görseller engellenebildiği ve gizlilik proxy'leri kullanılabildiği için bu bilgi, kişinin iletiyi okuduğunun kesin kanıtı değil yalnızca bir göstergedir.
- **Yardım asistanı:** Paketler, alan adları, ödeme ve destek için uygulama içindeki hazır yanıtları kullanır; API anahtarı veya harici AI servisi gerekmez.
- **Alan adı sorgulama:** Uzantı listesi IANA'nın RDAP dizininden alınır ve desteklenen uzantılar için ilgili kayıt kuruluşunun RDAP servisi sorgulanır. Sonuçlar yalnızca bilgilendirme amaçlıdır; alan adının uygunluğu, olası ek ücretler ve kayıt durumu bir alan adı kayıt kuruluşundan doğrulanmalıdır.

Siparişler ve ödemeler SQLite veritabanına kaydedilir. Hosting ve e-posta hizmetlerinin otomatik etkinleştirilmesi, alan adı satın alınması ve ödeme sağlayıcı hesabı oluşturulması için ayrıca ilgili sağlayıcıların yapılandırılması gerekir; uygulamanın yerel ortamda çalışması bu hizmetlerin hazır olduğu anlamına gelmez. Uygulamayı herkese açık olarak yayımlamadan önce HTTPS kullanın, `NODE_ENV=production` olarak ayarlayın, örnek paket koşullarını güncelleyin ve gerçek destek adresiyle entegrasyonları yapılandırın.